<?php

    class bannedTemplate extends template {
        
        public $blankElement = '';
        
    }

