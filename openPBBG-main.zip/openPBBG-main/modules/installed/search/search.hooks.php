<?php


    new hook("accountMenu", function () {
        return array(
            "url" => "?page=search", 
            "text" => "Player Search", 
            "sort" => 900
        );
    });
