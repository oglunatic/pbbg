<?php
    
	require 'config.php';
    require 'class/error.php';
    require 'init.php';

?>