# openPBBG
An open source game framework written in PHP using MySQL

## Current TODO List:

 - Update themes to use Bootstrap 5
 - Update Theme Editor with new BS5 themes and add the import/export pages
 - Update installer
 	- Check for needed PHP version & modules
 	- New UI