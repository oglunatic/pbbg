<?php

$config = array();

$config["debug"] = true;

$config["db"] = array(
    "host" => "localhost", 
    "database" => "glv2_2.6",
    "user" => "root",
    "pass" => "123"
);